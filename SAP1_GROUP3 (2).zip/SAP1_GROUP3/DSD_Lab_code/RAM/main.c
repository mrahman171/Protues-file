#include <stdio.h>

int main(void)
{
    FILE *file_ptr;

    unsigned char RamContent[] = {0x29,0x3A,0x3C,0x0B,0x70,0xF0,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};


    //printf("%d",sizeof(conRomInst));
    //printf("%c",conRomInst[10]);


    // Control rom 1 instruction write
    file_ptr = fopen("Ram.bin", "wb");
    //fwrite(conRomInst, sizeof(conRomInst), 25, file_ptr);
    fwrite(RamContent, sizeof(RamContent), 1, file_ptr);
    fclose(file_ptr);




    return 0;
}
